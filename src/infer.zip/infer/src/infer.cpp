#include "car/yolov5_car.h"
#include "armor/armor_infer.h"
#include <ros/ros.h>
#include "infer/img_result.h"
#include <iostream>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>

// 推理文件，使用TensorRT8.5.2.2推理yolov5s-6.2检测车辆，随后使用


//定义名称列表
std::string get_name(int index, std::string object)
{
    std::vector<std::string> car_name = {"car_unknown","car_red_0","car_blue_0"};
    std::vector<std::string> armor_name = {"car_blue_1", "car_blue_2", "car_blue_3", "car_blue_4", "car_blue_5", "car_blue_6",
                                "car_red_1", "car_red_2", "car_red_3", "car_red_4", "car_red_5", "car_red_6"};
    if(object == "car")
        return car_name[index];
    else if(object == "armor")
    {
        if(index == -1)//未识别到有效装甲板
            return "car_unknown";
        else
            return armor_name[index];
    } 
    else
        std::cerr << "object error!" << std::endl;

}
//获取车辆检测信息
infer::car_item get_car(int cols, int rows, Yolo_car::Detection result) 
{
    float l, r, t, b;
    float r_w = Yolo_car::INPUT_W / (cols * 1.0);
    float r_h = Yolo_car::INPUT_H / (rows * 1.0);
    if (r_h > r_w) {
        l = result.bbox[0] - result.bbox[2] / 2.f;
        r = result.bbox[0] + result.bbox[2] / 2.f;
        t = result.bbox[1] - result.bbox[3] / 2.f - (Yolo_car::INPUT_H - r_w * rows) / 2;
        b = result.bbox[1] + result.bbox[3] / 2.f - (Yolo_car::INPUT_H - r_w * rows) / 2;
        l = l / r_w;
        r = r / r_w;
        t = t / r_w;
        b = b / r_w;
    } else {
        l = result.bbox[0] - result.bbox[2] / 2.f - (Yolo_car::INPUT_W - r_h * cols) / 2;
        r = result.bbox[0] + result.bbox[2] / 2.f - (Yolo_car::INPUT_W - r_h * cols) / 2;
        t = result.bbox[1] - result.bbox[3] / 2.f;
        b = result.bbox[1] + result.bbox[3] / 2.f;
        l = l / r_h;
        r = r / r_h;
        t = t / r_h;
        b = b / r_h;
    }
    l = (std::max)(0.f, l);
    r = (std::min)((float)cols - 1.f, r);
    t = (std::max)(0.f, t);
    b = (std::min)((float)rows - 1.f, b);
    infer::car_item car;
    car.cls = get_name((int)result.class_id, "car");
    car.conf = result.conf;
    car.x0 = l;
    car.y0 = t;
    car.x1 = r;
    car.y1 = b;
    return car;
}
//获取装甲板检测信息
infer::armor_item get_armor(int cols, int rows, int x, int y, int car_id, Yolo_armor::Detection result)
{
    float l, r, t, b;
    infer::armor_item armor;
    if(result.class_id == -1)
    {
        l = 0;
        r = 0;
        t = 0;
        b = 0;
    }
    else
    {
        float r_w = Yolo_armor::INPUT_W / (cols * 1.0);
        float r_h = Yolo_armor::INPUT_H / (rows * 1.0);
        if (r_h > r_w) {
            l = result.bbox[0] - result.bbox[2] / 2.f;
            r = result.bbox[0] + result.bbox[2] / 2.f;
            t = result.bbox[1] - result.bbox[3] / 2.f - (Yolo_armor::INPUT_H - r_w * rows) / 2;
            b = result.bbox[1] + result.bbox[3] / 2.f - (Yolo_armor::INPUT_H - r_w * rows) / 2;
            l = l / r_w;
            r = r / r_w;
            t = t / r_w;
            b = b / r_w;
        } else {
            l = result.bbox[0] - result.bbox[2] / 2.f - (Yolo_armor::INPUT_W - r_h * cols) / 2;
            r = result.bbox[0] + result.bbox[2] / 2.f - (Yolo_armor::INPUT_W - r_h * cols) / 2;
            t = result.bbox[1] - result.bbox[3] / 2.f;
            b = result.bbox[1] + result.bbox[3] / 2.f;
            l = l / r_h;
            r = r / r_h;
            t = t / r_h;
            b = b / r_h;
        }
        l = (std::max)(0.f, l);
        r = (std::min)((float)cols - 1.f, r);
        t = (std::max)(0.f, t);
        b = (std::min)((float)rows - 1.f, b);   
    }
    armor.idx = car_id;
    armor.cls = result.class_id;
    armor.conf = result.conf;
    armor.x = l + x;
    armor.y = t + y;
    armor.w = r - l;
    armor.h = b - t;
    return armor;
}

int main(int argc, char** argv) 
{
    ros::init(argc, argv, "image_inference");
    ros::NodeHandle nh;
    //自定义msg
    ros::Publisher topic_publisher1 = nh.advertise<infer::img_result>("/infer/img1", 10);
    ros::Publisher topic_publisher2 = nh.advertise<infer::img_result>("/infer/img2", 10);
    infer::img_result img_results[2];
    cudaSetDevice(DEVICE);
    std::string car_engine = "";
    ros::param::get("yolov5_engine_car", car_engine);

    // 读取engine文件到内存
    std::ifstream file(car_engine, std::ios::binary);
    if (!file.good()) {
        std::cerr << "read " << car_engine << " error!" << std::endl;
        return -1;
    }
    char *trtModelStream = nullptr;
    size_t size = 0;
    file.seekg(0, file.end);
    size = file.tellg();
    file.seekg(0, file.beg);
    trtModelStream = new char[size];
    assert(trtModelStream);
    file.read(trtModelStream, size);
    file.close();

    // 定义TensorRT推理引擎，上下文，输入输出缓存
    static const int batch_size = 2;
    static float prob[batch_size * OUTPUT_SIZE];
    IRuntime* runtime = createInferRuntime(gLogger);
    assert(runtime != nullptr);
    ICudaEngine* engine = runtime->deserializeCudaEngine(trtModelStream, size);
    assert(engine != nullptr);
    IExecutionContext* context = engine->createExecutionContext();
    assert(context != nullptr);
    delete[] trtModelStream;
    assert(engine->getNbBindings() == 2); // 1 input and 1 output
    float* buffers[2];
    // 定义armor检测器
    TRTInfer_armor armor_infer(DEVICE);
    std::string armor_engine = "";
    std::string enemy_color = "";
    ros::param::get("yolov5_engine_armor", armor_engine);
    ros::param::get("enemy_color", enemy_color);
    armor_infer.initModule(armor_engine, 4, 12);

    // In order to bind the buffers, we need to know the names of the input and output tensors.
    // Note that indices are guaranteed to be less than IEngine::getNbBindings()
    const int inputIndex = engine->getBindingIndex(INPUT_BLOB_NAME);
    const int outputIndex = engine->getBindingIndex(OUTPUT_BLOB_NAME);
    assert(inputIndex == 0);
    assert(outputIndex == 1);

    // Create GPU buffers on device
    CUDA_CHECK(cudaMalloc((void**)&buffers[inputIndex], batch_size * 3 * Yolo_car::INPUT_H * Yolo_car::INPUT_W * sizeof(float)));
    CUDA_CHECK(cudaMalloc((void**)&buffers[outputIndex], batch_size * OUTPUT_SIZE * sizeof(float)));

    // Create stream
    cudaStream_t stream;
    CUDA_CHECK(cudaStreamCreate(&stream));
    uint8_t* img_host = nullptr;
    uint8_t* img_device = nullptr;

    // prepare input data cache in pinned memory 
    CUDA_CHECK(cudaMallocHost((void**)&img_host, MAX_IMAGE_INPUT_SIZE_THRESH * 3));
    // prepare input data cache in device memory
    CUDA_CHECK(cudaMalloc((void**)&img_device, MAX_IMAGE_INPUT_SIZE_THRESH * 3));

    // 创建共享内存
    int shm_fd1 = shm_open("/shared_memory1", O_RDWR | O_CREAT, 0666);
    if (shm_fd1 == -1) {
        std::cerr << "Failed to create shared memory1" << std::endl;
        return -1;
    }
    int shm_fd2 = shm_open("/shared_memory2", O_RDWR | O_CREAT, 0666);
    if (shm_fd2 == -1) {
        std::cerr << "Failed to create shared memory2" << std::endl;
        return -1;
    }

    // 设置共享内存大小
    size_t shm_size = 3088 * 2064 * 3;
    if (ftruncate(shm_fd1, shm_size) == -1) {
        std::cerr << "Failed to set shared memory1 size" << std::endl;
        shm_unlink("/shared_memory1");
        return -1;
    }
    if (ftruncate(shm_fd2, shm_size) == -1) {
        std::cerr << "Failed to set shared memory2 size" << std::endl;
        shm_unlink("/shared_memory2");
        return -1;
    }

    // 映射共享内存到进程地址空间
    void* shm_ptr1 = mmap(NULL, shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd1, 0);
    if (shm_ptr1 == MAP_FAILED) {
        std::cerr << "Failed to map shared memory1" << std::endl;
        shm_unlink("/shared_memory1");
        return -1;
    }
    // 映射共享内存到进程地址空间
    void* shm_ptr2 = mmap(NULL, shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd2, 0);
    if (shm_ptr2 == MAP_FAILED) {
        std::cerr << "Failed to map shared memory2" << std::endl;
        shm_unlink("/shared_memory2");
        return -1;
    }

    // 此处默认batch_size为2，可根据实际情况修改，模型的batch_size也要相应修改
    std::vector<cv::Mat> imgs_buffer(batch_size);
    std::string fps;
    while(ros::ok()) 
    {
        auto start1 = std::chrono::system_clock::now();
        float *buffer_idx = (float*)buffers[inputIndex];
        // 从共享内存中读取图像数据
        for(int b = 0; b < 2; b++) 
        {
            // 循环读取共享内存中的图像数据
            cv::Mat img(2064, 3088, CV_8UC3);
            if(b ==0)
                memcpy(img.data, shm_ptr1, shm_size);
            else
                memcpy(img.data, shm_ptr2, shm_size);
            if (img.empty()) continue;
            imgs_buffer[b] = img;
            size_t size_image = img.cols * img.rows * 3;
            size_t size_image_dst = Yolo_car::INPUT_H * Yolo_car::INPUT_W * 3;
            //copy data to pinned memory
            memcpy(img_host, img.data, size_image);
            //copy data to device memory
            CUDA_CHECK(cudaMemcpyAsync(img_device, img_host, size_image, cudaMemcpyHostToDevice, stream));
            preprocess_kernel_img(img_device, img.cols, img.rows, buffer_idx, Yolo_car::INPUT_W, Yolo_car::INPUT_H, stream);
            buffer_idx += size_image_dst;
        }
        std::cout << "preprocess time: " << std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() - start1).count() << "ms" << std::endl;
        // Run inference
        auto start = std::chrono::system_clock::now();
        doInference(*context, stream, (void**)buffers, prob, batch_size);
        auto end = std::chrono::system_clock::now();
        std::cout << "car inference time: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << "ms" << std::endl;
        std::vector<std::vector<Yolo_car::Detection>> batch_res(2);
        std::vector<cv::Mat> batch_roi;
        std::vector<int> img_idx;
        std::cout<<"batch_res size: "<<batch_res.size()<<std::endl;
        for(int b = 0; b < 2; b++) {
            auto& res = batch_res[b];
            cv::Mat img = imgs_buffer[b].clone();
            car_nms(res, &prob[b * OUTPUT_SIZE], CONF_THRESH, NMS_THRESH);
            for (size_t j = 0; j < res.size(); j++) 
            {
                if((int)res[j].class_id != 3)
                {
                    img_results[b].carlist.push_back(get_car(imgs_buffer[b].cols, imgs_buffer[b].rows, res[j]));
                    cv::Rect r = car_get_rect(imgs_buffer[b], res[j].bbox);
                    cv::Mat roi = cv::Mat(imgs_buffer[b], r);
                    batch_roi.push_back(roi.clone());
                    cv::rectangle(img, r, cv::Scalar(0x27, 0xC1, 0x36), 2);
                    img_idx.push_back((int)b*1000+j);//一张图检测出的车辆数量不会超过1000
                    cv::putText(img, std::to_string((int)res[j].class_id), cv::Point(r.x, r.y - 1), cv::FONT_HERSHEY_PLAIN, 2, cv::Scalar(0xFF, 0xFF, 0xFF), 3);
                    cv::putText(img, "FPS: " + fps, cv::Point(0, 70), cv::FONT_HERSHEY_PLAIN, 6, cv::Scalar(0xFF, 0xFF, 0xFF), 4);
                }
            }
            if (b == 0)
            {
                cv::Mat m;
                cv::resize(img, m, cv::Size(640, 480));
                cv::imshow("imgR", m);
                cv::waitKey(1);
            }     
        }
        // for(int i = 0; i < img_idx.size(); i++)
        // {
        //     std::cout<<img_idx[i]<<" ";
        // }
        std::vector<Yolo_armor::Detection> results;
        armor_infer.Inference(batch_roi, results, 0.15, enemy_color);
        assert(results.size() == img_idx.size());
        // if(results.size() > 0)
        //     std::cout<<"armor num: "<<results.size()<<std::endl;
        for(int i = 0; i < results.size(); i++)
        {
            int img_id = (int)img_idx[i]/1000;
            int car_id = (int)img_idx[i]%1000;
            // std::cout<<"img_id: "<<img_id<<" car_id: "<<car_id<<std::endl;
            // std::cout<<img_results[img_id].carlist.size()<<std::endl;
            // std::cout<<results[i].class_id<<std::endl;
            img_results[img_id].carlist[car_id].cls = get_name(results[i].class_id, "armor");
            int w = img_results[img_id].carlist[car_id].x1 - img_results[img_id].carlist[car_id].x0;
            int h = img_results[img_id].carlist[car_id].y1 - img_results[img_id].carlist[car_id].y0;
            int l = img_results[img_id].carlist[car_id].x0;
            int t = img_results[img_id].carlist[car_id].y0;
            img_results[img_id].armorlist.push_back(get_armor(w, h, l, t, car_id, results[i]));
        }
        // std::cout<<"img_results[0].carlist.size(): "<<img_results[0].carlist.size()<<std::endl;
        // std::cout<<"img_results[1].carlist.size(): "<<img_results[1].carlist.size()<<std::endl;
        // std::cout<<"img_results[0].armorlist.size(): "<<img_results[0].armorlist.size()<<std::endl;
        // std::cout<<"img_results[1].armorlist.size(): "<<img_results[1].armorlist.size()<<std::endl;
        topic_publisher1.publish(img_results[0]);
        topic_publisher2.publish(img_results[1]);
        img_results[0].carlist.clear();
        img_results[0].armorlist.clear();
        img_results[1].carlist.clear();
        img_results[1].armorlist.clear();
        auto end1 = std::chrono::system_clock::now();
        std::cout << "all time: " << std::chrono::duration_cast<std::chrono::milliseconds>(end1 - start1).count() << "ms" << std::endl;
        fps = std::to_string(1000.0 / std::chrono::duration_cast<std::chrono::milliseconds>(end1 - start1).count());
    }
    armor_infer.unInitModule();
    // Release stream and buffers
    cudaStreamDestroy(stream);
    CUDA_CHECK(cudaFree(img_device));
    CUDA_CHECK(cudaFreeHost(img_host));
    CUDA_CHECK(cudaFree(buffers[inputIndex]));
    CUDA_CHECK(cudaFree(buffers[outputIndex]));
    // Destroy the engine
    context->destroy();
    engine->destroy();
    runtime->destroy();
    // 解除映射并关闭共享内存
    munmap(shm_ptr1, shm_size);
    munmap(shm_ptr2, shm_size);
    close(shm_fd1);
    close(shm_fd2);
    shm_unlink("/shared_memory1");
    shm_unlink("/shared_memory2");
    return 0;
}
